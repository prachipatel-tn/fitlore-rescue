import json
import pytest
from langgraph.types import Command
from app import store
from app.agent import build_graph

@pytest.fixture(autouse=True)
def isolated(tmp_path,monkeypatch):
    monkeypatch.setenv('FITLORE_DATA_DIR',str(tmp_path))

def begin(scenario='standard',id='test'):
    store.new_project(id,scenario)
    g,c=build_graph();cfg={'configurable':{'thread_id':id},'recursion_limit':40}
    value=g.invoke(dict(run_id=id,question='Rescue the shoot',scenario=scenario,mode='rehearsal',observations=[],steps=0,status='running'),cfg)
    return g,c,cfg,value

def test_approval_and_duplicate_write():
    g,c,cfg,v=begin();assert v['status']=='awaiting_approval'
    assert store.get_project('test')['revision']==1
    done=g.invoke(Command(resume={'decision':'approve'}),cfg)
    assert done['status']=='complete'
    p=store.get_project('test');assert p['revision']==2
    assert all('G01' not in l['garment_ids'] and 'G02' in l['garment_ids'] for l in p['looks'])
    assert all(l['status']=='needs_fit_review' for l in p['looks'])
    store.apply('test',v['proposal']);assert store.get_project('test')['revision']==2
    c.close()

def test_rejection_does_not_change_plan():
    g,c,cfg,v=begin();before=store.get_project('test')
    assert g.invoke(Command(resume={'decision':'reject'}),cfg)['status']=='rejected'
    assert store.get_project('test')==before;c.close()

def test_resume_after_reopening_checkpoint():
    g,c,cfg,v=begin();c.close()
    g,c=build_graph();assert g.get_state(cfg).values['proposal']==v['proposal']
    assert g.invoke(Command(resume={'decision':'approve'}),cfg)['status']=='complete';c.close()

def test_transient_failure_recovers():
    g,c,cfg,v=begin('transient_failure')
    assert v['status']=='awaiting_approval'
    calls=[o for o in v['observations'] if o['tool']=='search_wardrobe']
    assert len(calls)==2 and 'error' in calls[0]['result'] and 'garments' in calls[1]['result'];c.close()

@pytest.mark.parametrize('scenario',['permanent_failure','no_match'])
def test_safe_handoff(scenario):
    g,c,cfg,v=begin(scenario);assert v['status']=='handoff'
    assert store.get_project('test')['revision']==1
    assert 'proposal' not in v;c.close()

def test_stale_approval_blocked():
    g,c,cfg,v=begin()
    with store.connection() as db:
        p=store.get_project('test');p['revision']+=1
        db.execute('UPDATE projects SET payload=? WHERE id=?',(json.dumps(p),'test'))
    assert g.invoke(Command(resume={'decision':'approve'}),cfg)['status']=='handoff'
    assert store.get_project('test')['looks'][0]['garment_ids'][0]=='G01';c.close()

@pytest.mark.parametrize('id',['G01','G03','G04','G05','G06','does-not-exist'])
def test_invalid_replacements(id):
    store.new_project('test','standard')
    assert not store.check_candidate(store.get_project('test'),id)['ok']

def test_budget_cap():
    for _ in range(20):store.reserve()
    with pytest.raises(RuntimeError):store.reserve()
    assert store.usage()==20

def test_recheck_availability_before_commit():
    g,c,cfg,v=begin()
    with store.connection() as db:
        p=store.get_project('test');p['garments'][1]['available']=False
        db.execute('UPDATE projects SET payload=? WHERE id=?',(json.dumps(p),'test'))
    assert g.invoke(Command(resume={'decision':'approve'}),cfg)['status']=='handoff';c.close()

def test_model_cannot_skip_required_evidence(monkeypatch):
    from app import agent
    monkeypatch.setattr(agent,'rehearsal_decision',lambda s:dict(tool='propose_replacement',candidate_id='G02',reason='Skip all checks'))
    g,c,cfg,v=begin();assert v['status']=='handoff'
    assert 'proposal' not in v and store.get_project('test')['revision']==1;c.close()

def test_model_failure_hands_off_without_write(monkeypatch):
    from app import agent
    def fail(s):raise RuntimeError('Provider unavailable')
    monkeypatch.setattr(agent,'model_decision',fail)
    store.new_project('test','standard');g,c=build_graph()
    v=g.invoke(dict(run_id='test',question='Rescue',scenario='standard',mode='live',observations=[],steps=0,status='running'),{'configurable':{'thread_id':'test'}})
    assert v['status']=='handoff' and store.get_project('test')['revision']==1;c.close()

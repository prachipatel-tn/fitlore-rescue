import json
import pytest
from app import store
from app.fixtures import project
from app.schemas import ShootInput,parse_csv
from app.agent import build_graph
from langgraph.types import Command

@pytest.fixture(autouse=True)
def isolated(tmp_path,monkeypatch):monkeypatch.setenv('FITLORE_DATA_DIR',str(tmp_path))

def body():
    p=project();keys=ShootInput.model_fields
    p={k:v for k,v in p.items() if k in keys}
    for g in p['garments']:g.pop('image',None)
    for l in p['looks']:l.pop('status',None)
    return ShootInput.model_validate(p)

def run():
    store.save_shoot('shoot',body());store.snapshot_shoot('run','shoot')
    g,c=build_graph();cfg={'configurable':{'thread_id':'run'},'recursion_limit':40}
    v=g.invoke(dict(run_id='run',question='Rescue',mode='rehearsal',scenario='standard',observations=[],steps=0,status='running'),cfg)
    return g,c,cfg,v

def test_master_updates_only_after_approval():
    g,c,cfg,v=run();assert store.shoots()[0]['revision']==1
    assert g.invoke(Command(resume={'decision':'approve'}),cfg)['status']=='complete'
    assert store.shoots()[0]['revision']==2
    assert all('G02' in l['garment_ids'] for l in store.shoots()[0]['looks'])
    with pytest.raises(ValueError):store.snapshot_shoot('second','shoot')
    c.close()

def test_concurrent_master_edit_blocks_approval():
    g,c,cfg,v=run();b=body();b.budget=10;store.save_shoot('shoot',b,1)
    assert g.invoke(Command(resume={'decision':'approve'}),cfg)['status']=='handoff'
    assert store.shoots()[0]['looks'][0]['garment_ids'][0]=='G01';c.close()

def test_invalid_human_alternative_never_writes():
    g,c,cfg,v=run()
    assert g.invoke(Command(resume={'decision':'approve','candidate_id':'G04'}),cfg)['status']=='handoff'
    assert store.shoots()[0]['revision']==1;c.close()

def test_valid_human_alternative_updates_receipt():
    b=body();b.garments[2].color='navy';store.save_shoot('shoot',b);store.snapshot_shoot('run','shoot')
    g,c=build_graph();cfg={'configurable':{'thread_id':'run'},'recursion_limit':40}
    g.invoke(dict(run_id='run',question='Rescue',mode='rehearsal',scenario='standard',observations=[],steps=0,status='running'),cfg)
    v=g.invoke(Command(resume={'decision':'approve','candidate_id':'G03'}),cfg)
    assert v['status']=='complete' and v['proposal']['candidate_id']=='G03'
    assert store.shoots()[0]['replacement_cost']==25;c.close()

def test_custom_category_and_color():
    b=body();b.required_color='white';b.required_sleeves='short'
    for g in b.garments[:2]:g.category='shirt';g.color='white';g.sleeves='short'
    p=b.project('x');assert store.check_candidate(p,'G02')['ok']

def test_csv_and_reference_validation():
    with pytest.raises(ValueError):parse_csv('id,name\nx,a')
    p=body().model_dump();p['looks'][0]['garment_ids']=['unknown']
    with pytest.raises(ValueError):ShootInput.model_validate(p)

def test_optimistic_editor_conflict():
    store.save_shoot('x',body())
    with pytest.raises(ValueError):store.save_shoot('x',body(),0)

def test_authorized_limit_configurable(monkeypatch):
    monkeypatch.setenv('FITLORE_REQUEST_LIMIT','80')
    for _ in range(80):store.reserve()
    with pytest.raises(RuntimeError):store.reserve()

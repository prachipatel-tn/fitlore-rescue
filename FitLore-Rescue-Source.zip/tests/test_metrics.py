from app.metrics import result,summary

def record(status='complete',mode='live'):
    return dict(id='x',measurement_version=1,mode=mode,status=status,created='2026-10-25T12:00:00+00:00',approval_ready_at='2026-10-25T12:00:05+00:00',review_submitted_at='2026-10-25T12:02:00+00:00',finished_at='2026-10-25T12:02:01+00:00',processing_seconds=6)

def test_human_wait_included_and_no_inferred_acceptance():
    r=record();m=result(r)
    assert m['approval_wait_seconds']==115 and m['terminal_seconds']==121
    assert m['end_to_end_seconds'] is None and not m['meets_target']
    r['outcome_review']={'at':'2026-10-25T12:02:30+00:00','usable':True,'note':'Plan checked'}
    assert result(r)['end_to_end_seconds']==150 and result(r)['meets_target']

def test_slow_usable_plan_fails_time_target():
    r=record();r['outcome_review']={'at':'2026-10-25T12:04:00+00:00','usable':True}
    assert result(r)['confirmed_usable'] and not result(r)['meets_target']

def test_safe_handoff_is_not_successful_recovery():
    r=record('handoff');r['outcome_review']={'at':'2026-10-25T12:02:30+00:00','usable':True}
    assert not result(r)['confirmed_usable']

def test_legacy_is_not_backfilled():
    assert not result({'created':'2026-10-25T12:00:00+00:00'})['instrumented']

def test_all_live_starts_stay_in_denominator():
    good=record();good['outcome_review']={'at':'2026-10-25T12:02:30+00:00','usable':True}
    s=summary([good,record('running'),record('handoff'),record(mode='rehearsal'),{'mode':'live','status':'complete'}])
    assert s['started']==3 and s['within_target']==1 and s['success_rate']==0.333
    assert s['pending']==1 and s['outcomes']['handoff']==1 and not s['pilot_ready']

def test_api_records_outcome_once_and_preserves_measurement(tmp_path,monkeypatch):
    monkeypatch.setenv('FITLORE_DATA_DIR',str(tmp_path))
    from fastapi.testclient import TestClient
    from app.main import app
    client=TestClient(app)
    id=client.post('/api/runs',json={'mode':'rehearsal'}).json()['id']
    r=client.get('/api/runs/'+id).json()
    assert r['status']=='awaiting_approval' and r['measurement']['instrumented']
    assert client.post(f'/api/runs/{id}/outcome',json={'usable':True,'note':'Checked'}).status_code==409
    client.post(f'/api/runs/{id}/review',json={'decision':'approve'})
    response=client.post(f'/api/runs/{id}/outcome',json={'usable':True,'note':'Both looks have the replacement and fit review remains open.'})
    assert response.status_code==200 and response.json()['confirmed_usable']
    assert response.json()['end_to_end_seconds']>=response.json()['terminal_seconds']
    assert client.post(f'/api/runs/{id}/outcome',json={'usable':False,'note':'overwrite'}).status_code==409
    assert client.get('/api/workspace').json()['measurement_summary']['started']==0
    assert client.get(f'/api/runs/{id}/export').json()['measurement']['operator_review']['source']=='operator self-report'

def test_handoff_cannot_be_marked_recovered(tmp_path,monkeypatch):
    monkeypatch.setenv('FITLORE_DATA_DIR',str(tmp_path))
    from fastapi.testclient import TestClient
    from app.main import app
    client=TestClient(app)
    id=client.post('/api/runs',json={'mode':'rehearsal','scenario':'no_match'}).json()['id']
    assert client.post(f'/api/runs/{id}/outcome',json={'usable':True,'note':'False success'}).status_code==422

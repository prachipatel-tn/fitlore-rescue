"""Fictional, reproducible FitLore shoot. Images are category inspiration only."""
from copy import deepcopy

GARMENTS = [
    dict(id='G01', name='Hero navy blazer', category='jacket', color='navy', size='M', sleeves='long', available=False, ready_hour=8, cost=0, image='free-navy-blazer.jpg'),
    dict(id='G02', name='Studio navy blazer', category='jacket', color='navy', size='M', sleeves='long', available=True, ready_hour=9, cost=45, image='free-navy-blazer.jpg'),
    dict(id='G03', name='Grey tailored jacket', category='jacket', color='grey', size='M', sleeves='long', available=True, ready_hour=8, cost=25, image='edit-tailoring.jpg'),
    dict(id='G04', name='Evening delivery blazer', category='jacket', color='navy', size='M', sleeves='long', available=True, ready_hour=18, cost=20, image='free-navy-blazer.jpg'),
    dict(id='G05', name='Small navy blazer', category='jacket', color='navy', size='S', sleeves='long', available=True, ready_hour=8, cost=15, image='free-navy-blazer.jpg'),
    dict(id='G06', name='White cotton shirt', category='shirt', color='white', size='M', sleeves='long', available=True, ready_hour=8, cost=0, image='free-white-shirt.jpg'),
    dict(id='G07', name='Grey trousers', category='trousers', color='grey', size='M', sleeves='none', available=True, ready_hour=8, cost=0, image='free-grey-trousers.jpg'),
    dict(id='G08', name='Black loafers', category='shoes', color='black', size='38', sleeves='none', available=True, ready_hour=8, cost=0, image='free-black-loafers.jpg'),
]

def project(scenario='standard'):
    p = dict(id='shoot-01', revision=1, title='The Monday Edit', client='Fictional client · Forma Studio',
        brief='A quiet, tailored city editorial. Preserve navy outerwear, long sleeves and size M. Both looks share the jacket at different shoot slots. Physical fit still needs a stylist check.',
        budget=60, call_hour=10, required_color='navy', required_size='M',
        failed_id='G01', garments=deepcopy(GARMENTS),
        looks=[dict(id='L01', title='City arrival', slot='10:00', garment_ids=['G01','G06','G07','G08'], status='blocked'),
               dict(id='L02', title='Studio portrait', slot='11:30', garment_ids=['G01','G06','G07'], status='blocked')],
        tasks=[dict(id='T01', title='Stylist fit check', status='needs_review'), dict(id='T02', title='Photographer look approval', status='blocked')])
    if scenario == 'no_match':
        p['garments'][1]['available'] = False
    return p

import json
import os
import threading
import uuid
from pathlib import Path
from typing import Literal
from fastapi import FastAPI, BackgroundTasks, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from langgraph.types import Command
from app import store
from app.schemas import ShootInput, parse_csv
from app.agent import build_graph, config
from app.fixtures import project

app=FastAPI(title='FitLore Rescue')
app.mount('/static',StaticFiles(directory='web'),name='static')
locks={}
registry_lock=threading.Lock()

def lock_for(id):
    with registry_lock: return locks.setdefault(id,threading.Lock())

@app.middleware('http')
async def local_writes(request:Request,call_next):
    if request.method=='POST':
        origin=request.headers.get('origin')
        if origin and origin != str(request.base_url).rstrip('/'):
            return JSONResponse({'detail':'Cross-origin writes are not allowed.'},status_code=403)
    return await call_next(request)

@app.get('/')
def home(): return FileResponse('web/index.html')

@app.get('/api/workspace')
def workspace():
    settings=config()
    return dict(project=project(),runs=store.runs(),usage=store.usage(),limit=store.request_limit(),shoots=store.shoots(),
        model=settings.get('NEBIUS_MODEL','Not connected'),live_ready=bool(settings.get('NEBIUS_API_KEY')) and os.getenv('FITLORE_ALLOW_MODEL')=='true')

class Start(BaseModel):
    shoot_id:str|None=None
    question:str=Field(default='The hero jacket is unavailable. Rescue tomorrow’s shoot within the brief and budget.',min_length=5,max_length=1200)
    scenario:Literal['standard','transient_failure','permanent_failure','no_match']='standard'
    mode:Literal['live','rehearsal']='live'

class Review(BaseModel):
    decision:Literal['approve','reject']
    candidate_id:str|None=None
    note:str=Field(default='',max_length=1000)

def cfg(id): return {'configurable':{'thread_id':id},'recursion_limit':40}

def work(id,input):
    with lock_for(id):
        graph,conn=build_graph()
        try:
            value=graph.invoke(input,cfg(id))
            r=store.run(id);r['status']=value.get('status','handoff');store.save_run(r)
        except Exception as e:
            # Provider response bodies and credentials must never enter logs or UI.
            store.event(id,'error','Run paused unexpectedly',type(e).__name__+': resume the saved run or review its evidence.')
            r=store.run(id);r['status']='interrupted';store.save_run(r)
        finally: conn.close()

@app.post('/api/runs')
def start(body:Start,tasks:BackgroundTasks):
    if body.mode=='live' and not workspace()['live_ready']: raise HTTPException(409,'Live model is not configured.')
    if body.mode=='live' and store.usage()>=store.request_limit(): raise HTTPException(409,'The authorized request allowance is exhausted. Rehearsal remains available.')
    id=str(uuid.uuid4())
    try:
        if body.shoot_id:
            if body.scenario!='standard':raise ValueError('Fault injection is limited to the fictional demo.')
            store.snapshot_shoot(id,body.shoot_id)
        else:store.new_project(id,body.scenario)
    except (KeyError,ValueError) as e:raise HTTPException(409,str(e))
    store.save_run(dict(id=id,status='running',created=store.now(),question=body.question,scenario=body.scenario,mode=body.mode))
    store.event(id,'start','Investigation started',{'mode':body.mode,'scenario':body.scenario})
    tasks.add_task(work,id,dict(run_id=id,question=body.question,scenario=body.scenario,mode=body.mode,observations=[],steps=0,status='running'))
    return {'id':id}

@app.get('/api/runs/{id}')
def detail(id:str):
    try: r=store.run(id)
    except KeyError: raise HTTPException(404,'Run not found')
    graph,conn=build_graph()
    try:
        snapshot=graph.get_state(cfg(id));values=dict(snapshot.values)
    finally: conn.close()
    status=values.get('status',r['status'])
    if r['status']=='interrupted': status='interrupted'
    return dict(**{**r,'status':status},state=values,events=store.events(id),project=store.get_project(id),busy=lock_for(id).locked(),eligible=[g['id'] for g in store.get_project(id)['garments'] if store.check_candidate(store.get_project(id),g['id'])['ok']])

@app.post('/api/runs/{id}/review')
def review(id:str,body:Review,tasks:BackgroundTasks):
    r=detail(id)
    if r['busy']: raise HTTPException(409,'This run is still working.')
    if r['status']=='complete': return {'id':id,'status':'complete'}
    if r['status']!='awaiting_approval': raise HTTPException(409,'This run is not awaiting approval.')
    # Serialize the pending response claim before scheduling any work.
    with lock_for(id):
        metadata=store.run(id)
        if metadata['status']=='resuming': raise HTTPException(409,'An approval is already being processed.')
        metadata['status']='resuming';store.save_run(metadata)
    tasks.add_task(work,id,Command(resume=body.model_dump()))
    return {'id':id,'status':'resuming'}

@app.post('/api/runs/{id}/resume')
def resume(id:str,tasks:BackgroundTasks):
    r=detail(id)
    if r['busy'] or r['status'] not in ['running','interrupted']: raise HTTPException(409,'No interrupted investigation to resume.')
    tasks.add_task(work,id,None)
    return {'id':id}

@app.get('/api/runs/{id}/export')
def export(id:str):
    r=detail(id)
    return JSONResponse(r,headers={'Content-Disposition':f'attachment; filename="fitlore-run-{id}.json"'})


class ShootSave(BaseModel):
    shoot:ShootInput
    id:str|None=None
    revision:int|None=None

@app.post('/api/shoots')
def save_shoot(body:ShootSave):
    if body.id and body.revision is None:raise HTTPException(422,'Revision required for edits')
    try:return store.save_shoot(body.id or str(uuid.uuid4()),body.shoot,body.revision)
    except ValueError as e:raise HTTPException(409,str(e))

class CsvInput(BaseModel):
    text:str=Field(max_length=50000)

@app.post('/api/wardrobe/parse')
def wardrobe_csv(body:CsvInput):
    try:return {'garments':parse_csv(body.text)}
    except ValueError as e:raise HTTPException(422,str(e))

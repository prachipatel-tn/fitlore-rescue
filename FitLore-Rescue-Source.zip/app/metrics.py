"""Explicit workflow metrics. Never infer user acceptance from an agent status."""
from datetime import datetime

TARGET_SECONDS=180
TERMINAL={'complete','rejected','handoff'}

def seconds(start,end):
    if not start or not end:return None
    return round(max(0,(datetime.fromisoformat(end)-datetime.fromisoformat(start)).total_seconds()),3)

def result(run):
    if run.get('measurement_version')!=1:
        return {'instrumented':False,'message':'Historical run: user-inclusive timing was not collected.'}
    feedback=run.get('outcome_review')
    end=feedback['at'] if feedback else run.get('finished_at')
    total=seconds(run['created'],end)
    confirmed=bool(feedback and feedback['usable'] and run['status']=='complete')
    return dict(instrumented=True,protocol='Start investigation → operator confirms usable revised plan; includes waiting and human review. Physical fit is outside this task.',
        terminal_seconds=seconds(run['created'],run.get('finished_at')),
        end_to_end_seconds=seconds(run['created'],feedback['at']) if feedback else None,
        approval_wait_seconds=seconds(run.get('approval_ready_at'),run.get('review_submitted_at')),
        processing_seconds=round(run.get('processing_seconds',0),3),
        outcome=run['status'],operator_review=feedback,
        confirmed_usable=confirmed,target_seconds=TARGET_SECONDS,
        meets_target=bool(confirmed and total is not None and total<=TARGET_SECONDS),
        manual_baseline_seconds=feedback.get('manual_baseline_seconds') if feedback else None,
        comparison_note='Manual baseline is operator-reported; use the same task and timing boundary. No savings claim is calculated automatically.')

def summary(runs):
    cohort=[r for r in runs if r.get('measurement_version')==1 and r.get('mode')=='live']
    measured=[result(r) for r in cohort]
    counts={k:sum(r['status']==k for r in cohort) for k in ['complete','handoff','rejected']}
    return dict(protocol='All instrumented live UI starts; rehearsals and historical automated evaluations excluded. Pending and unreviewed runs remain in the denominator.',
        started=len(cohort),outcomes=counts,pending=sum(r['status'] not in TERMINAL for r in cohort),
        confirmed_usable=sum(m['confirmed_usable'] for m in measured),within_target=sum(m['meets_target'] for m in measured),
        success_rate=round(sum(m['meets_target'] for m in measured)/len(cohort),3) if cohort else None,
        target='At least 8 of 10 live tasks produce an operator-confirmed usable plan within 180 seconds, including human review.',
        pilot_ready=len(cohort)>=10,independent_user_validation=False)

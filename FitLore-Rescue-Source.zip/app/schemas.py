"""Strict input contracts for user-owned shoot and wardrobe records."""
import csv
import io
from typing import Literal
from pydantic import BaseModel, Field, model_validator, field_validator, ConfigDict

Id = str
class Garment(BaseModel):
    model_config=ConfigDict(extra='forbid')
    id:str=Field(pattern=r'^[A-Za-z0-9_-]{1,30}$')
    name:str=Field(min_length=1,max_length=100)
    category:str=Field(min_length=1,max_length=30)
    color:str=Field(min_length=1,max_length=30)
    size:str=Field(min_length=1,max_length=20)
    sleeves:Literal['long','short','none']='long'
    available:bool
    ready_hour:int=Field(ge=0,le=23)
    cost:int=Field(ge=0,le=100000)
    @field_validator('category','color')
    @classmethod
    def normalize(cls,v):return v.strip().lower()
    @field_validator('name','size')
    @classmethod
    def strip_text(cls,v):
        v=v.strip()
        if not v:raise ValueError('Cannot be blank')
        return v

class Look(BaseModel):
    model_config=ConfigDict(extra='forbid')
    id:str=Field(pattern=r'^[A-Za-z0-9_-]{1,30}$')
    title:str=Field(min_length=1,max_length=100)
    slot:str=Field(pattern=r'^(?:[01][0-9]|2[0-3]):[0-5][0-9]$')
    garment_ids:list[str]=Field(min_length=1,max_length=20)

class ShootInput(BaseModel):
    model_config=ConfigDict(extra='forbid')
    title:str=Field(min_length=1,max_length=120)
    client:str=Field(default='',max_length=120)
    brief:str=Field(min_length=5,max_length=3000)
    budget:int=Field(ge=0,le=100000)
    call_hour:int=Field(ge=0,le=23)
    required_color:str=Field(min_length=1,max_length=30)
    required_size:str=Field(min_length=1,max_length=20)
    required_sleeves:Literal['long','short','none']='long'
    failed_id:str
    garments:list[Garment]=Field(min_length=2,max_length=60)
    looks:list[Look]=Field(min_length=1,max_length=20)
    @field_validator('required_color')
    @classmethod
    def color(cls,v):return v.strip().lower()
    @model_validator(mode='after')
    def references(self):
        ids=[g.id for g in self.garments]
        if len(set(ids))!=len(ids):raise ValueError('Garment IDs must be unique')
        if self.failed_id not in ids:raise ValueError('Missing garment must exist in inventory')
        failed=next(g for g in self.garments if g.id==self.failed_id)
        if failed.available:raise ValueError('The missing garment must be marked unavailable')
        if len({l.id for l in self.looks})!=len(self.looks):raise ValueError('Look IDs must be unique')
        for l in self.looks:
            if len(set(l.garment_ids))!=len(l.garment_ids):raise ValueError('A look cannot repeat a garment ID')
            if not set(l.garment_ids)<=set(ids):raise ValueError('Every look garment must exist in inventory')
        if not any(self.failed_id in l.garment_ids for l in self.looks):raise ValueError('At least one look must use the missing garment')
        return self
    def project(self,id,revision=1):
        p=self.model_dump();p.update(id=id,revision=revision,data_origin='user supplied',required_category=next(g.category for g in self.garments if g.id==self.failed_id),
            tasks=[dict(id='T01',title='Stylist physical fit check',status='needs_review'),dict(id='T02',title='Photographer look approval',status='blocked')])
        for l in p['looks']:l['status']='blocked' if p['failed_id'] in l['garment_ids'] else 'unchanged'
        return p

COLUMNS=['id','name','category','color','size','sleeves','available','ready_hour','cost']
def parse_csv(text):
    if len(text)>50000:raise ValueError('CSV is limited to 50,000 characters')
    reader=csv.DictReader(io.StringIO(text.lstrip('\ufeff')))
    if reader.fieldnames!=COLUMNS:raise ValueError('CSV headers must be: '+','.join(COLUMNS))
    items=[]
    for n,row in enumerate(reader,2):
        if len(items)>=60:raise ValueError('At most 60 garment records')
        if None in row or any(v is None for v in row.values()):raise ValueError(f'Row {n} has the wrong number of columns')
        if row['available'].lower() not in ['true','false']:raise ValueError(f'Row {n}: available must be true or false')
        row['available']=row['available'].lower()=='true'
        items.append(Garment.model_validate(row).model_dump())
    if len(items)<2:raise ValueError('Provide at least two garments')
    if len({g['id'] for g in items})!=len(items):raise ValueError('Garment IDs must be unique')
    return items

import json
import os
import sqlite3
from pathlib import Path
from datetime import datetime, timezone
from app.fixtures import project

def now():
    return datetime.now(timezone.utc).isoformat()

def connection():
    root = Path(os.getenv('FITLORE_DATA_DIR', 'data/runtime'))
    root.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(root / 'workspace.sqlite3', timeout=20)
    c.row_factory = sqlite3.Row
    c.executescript('''CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY, payload TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS shoots(id TEXT PRIMARY KEY, payload TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY, payload TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT, payload TEXT);
    CREATE TABLE IF NOT EXISTS applied(run_id TEXT PRIMARY KEY, payload TEXT);
    CREATE TABLE IF NOT EXISTS usage(id INTEGER PRIMARY KEY, attempts INTEGER);''')
    return c

def save_run(r):
    with connection() as c:
        c.execute('INSERT OR REPLACE INTO runs VALUES (?,?)', (r['id'], json.dumps(r)))

def run(id):
    with connection() as c:
        r = c.execute('SELECT payload FROM runs WHERE id=?', (id,)).fetchone()
        if not r: raise KeyError('Run not found')
        return json.loads(r[0])

def runs():
    with connection() as c:
        return [json.loads(r[0]) for r in c.execute('SELECT payload FROM runs ORDER BY rowid DESC LIMIT 30')]

def new_project(run_id, scenario):
    p = project(scenario)
    p['id'] = run_id
    with connection() as c:
        c.execute('INSERT INTO projects VALUES (?,?)', (run_id, json.dumps(p)))
    return p

def get_project(id):
    with connection() as c:
        r = c.execute('SELECT payload FROM projects WHERE id=?', (id,)).fetchone()
        if not r: raise KeyError('Project not found')
        return json.loads(r[0])

def event(id, kind, title, detail):
    with connection() as c:
        c.execute('INSERT INTO events(run_id,payload) VALUES (?,?)', (id, json.dumps(dict(time=now(),kind=kind,title=title,detail=detail))))

def events(id):
    with connection() as c:
        return [json.loads(r[0]) for r in c.execute('SELECT payload FROM events WHERE run_id=? ORDER BY seq', (id,))]

def request_limit():
    return int(os.getenv("FITLORE_REQUEST_LIMIT", "20"))

def reserve():
    with connection() as c:
        c.execute('BEGIN IMMEDIATE')
        row = c.execute('SELECT attempts FROM usage WHERE id=1').fetchone()
        used = row[0] if row else 0
        if used >= request_limit(): raise RuntimeError('The authorized model request allowance has been reached.')
        c.execute('INSERT OR REPLACE INTO usage VALUES(1,?)', (used+1,))

def usage():
    with connection() as c:
        r = c.execute('SELECT attempts FROM usage WHERE id=1').fetchone()
        return r[0] if r else 0

def check_candidate(p, candidate_id):
    g = next((g for g in p['garments'] if g['id']==candidate_id), None)
    if not g: return dict(ok=False, reasons=['Unknown garment ID'], candidate_id=candidate_id)
    reasons = []
    for ok, reason in [(g['available'], 'Unavailable'), (g['category']==p.get('required_category','jacket'), 'Wrong category'),
        (g['color']==p['required_color'], 'Outside approved color palette'),
        (g['size']==p['required_size'], 'Wrong recorded size'), (g['sleeves']==p.get('required_sleeves','long'), 'Sleeve coverage mismatch'),
        (g['ready_hour']<=p['call_hour'], 'Arrives after call time'), (g['cost']<=p['budget'], 'Over replacement budget')]:
        if not ok: reasons.append(reason)
    if candidate_id==p['failed_id']: reasons.append('Cannot replace a garment with itself')
    for look in p['looks']:
        if p['failed_id'] in look['garment_ids'] and candidate_id in look['garment_ids']: reasons.append('Already used in affected look '+look['id'])
    return dict(ok=not reasons, reasons=reasons, candidate_id=candidate_id, cost=g['cost'],
                evidence_ids=['BRIEF-01',g['id']], caveat='Recorded size only; physical fit requires stylist confirmation.')

def apply(id, proposal):
    with connection() as c:
        c.execute('BEGIN IMMEDIATE')
        prior=c.execute('SELECT payload FROM applied WHERE run_id=?',(id,)).fetchone()
        if prior: return json.loads(prior[0])
        p=json.loads(c.execute('SELECT payload FROM projects WHERE id=?',(id,)).fetchone()[0])
        source_id=p.get('source_id')
        if source_id:
            master=json.loads(c.execute('SELECT payload FROM shoots WHERE id=?',(source_id,)).fetchone()[0])
            if master['revision'] != p['revision']: raise ValueError('Shoot changed since investigation. Start a fresh investigation.')
            p={**master,'id':id,'source_id':source_id}
        if p['revision'] != proposal['revision']: raise ValueError('Project changed since review. Start a fresh investigation.')
        valid=check_candidate(p,proposal['candidate_id'])
        if not valid['ok']: raise ValueError('Replacement no longer meets the brief: '+', '.join(valid['reasons']))
        changed=[]
        for look in p['looks']:
            if p['failed_id'] in look['garment_ids']:
                look['garment_ids']=[proposal['candidate_id'] if x==p['failed_id'] else x for x in look['garment_ids']]
                look['status']='needs_fit_review';changed.append(look['id'])
        if not changed: raise ValueError('No affected looks remain.')
        p['revision']+=1;p['replacement_cost']=valid['cost']
        result=dict(changed_looks=changed, revision=p['revision'], replacement_cost=valid['cost'],
                    message='Local shoot plan updated. Stylist fit check and photographer approval remain open.')
        c.execute('UPDATE projects SET payload=? WHERE id=?',(json.dumps(p),id))
        if source_id:
            master={**p,'id':source_id};master.pop('source_id',None)
            c.execute('UPDATE shoots SET payload=? WHERE id=?',(json.dumps(master),source_id))
        c.execute('INSERT INTO applied VALUES(?,?)',(id,json.dumps(result)))
        return result


def shoots():
    with connection() as c:
        return [json.loads(r[0]) for r in c.execute('SELECT payload FROM shoots ORDER BY rowid DESC')]

def save_shoot(id, body, expected_revision=None):
    with connection() as c:
        c.execute('BEGIN IMMEDIATE')
        old=c.execute('SELECT payload FROM shoots WHERE id=?',(id,)).fetchone()
        revision=json.loads(old[0])['revision'] if old else 0
        if expected_revision is not None and revision!=expected_revision: raise ValueError('Shoot changed. Reload before saving.')
        p=body.project(id,revision+1)
        c.execute('INSERT OR REPLACE INTO shoots VALUES (?,?)',(id,json.dumps(p)))
        return p

def snapshot_shoot(run_id,source_id):
    with connection() as c:
        row=c.execute('SELECT payload FROM shoots WHERE id=?',(source_id,)).fetchone()
        if not row: raise KeyError('Shoot not found')
        p=json.loads(row[0]);p.update(id=run_id,source_id=source_id)
        if not any(p['failed_id'] in l['garment_ids'] for l in p['looks']): raise ValueError('This incident is resolved. Edit the shoot to describe a new incident.')
        c.execute('INSERT INTO projects VALUES (?,?)',(run_id,json.dumps(p)))
        return p

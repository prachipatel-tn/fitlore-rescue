from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from PIL import Image, ImageDraw, ImageFont

out=Path('output/submission');out.mkdir(parents=True,exist_ok=True)
im=Image.new('RGB',(1400,500),'white');draw=ImageDraw.Draw(im)
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',26)
small=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',22)
boxes=[(20,40,310,160,'Model chooses a tool'),(390,40,750,160,'Read and check evidence'),(830,40,1370,160,'Validated proposal'),(830,290,1370,420,'Human approves or rejects'),(390,290,750,420,'Recheck and save once'),(20,290,310,420,'SQLite stores state')]
for x,y,x2,y2,label in boxes:
 draw.rounded_rectangle((x,y,x2,y2),radius=10,fill='#eef1e7',outline='#c5ccba',width=2)
 draw.text(((x+x2)/2,(y+y2)/2),label,font=font,anchor='mm',fill='#252820')
for start,end in [((312,100),(387,100)),((752,100),(827,100)),((1100,163),(1100,287)),((827,355),(753,355)),((387,355),(313,355))]:
 draw.line([start,end],fill='#647344',width=4)
 x,y=end;dx=end[0]-start[0];dy=end[1]-start[1]
 pts=[(x,y),(x-12,y-7),(x-12,y+7)] if dx>0 else [(x,y),(x+12,y-7),(x+12,y+7)] if dx<0 else [(x,y),(x-7,y-12),(x+7,y-12)]
 draw.polygon(pts,fill='#647344')
draw.text((390,205),'Tool results return to the model until proposal or handoff',font=small,fill='#50574b')
draw.text((30,465),'No safe option, repeated tool failure, or step limit  →  stylist handoff',font=small,fill='#50574b')
im.save(out/'architecture.png')

d=Document();sec=d.sections[0];sec.top_margin=sec.bottom_margin=Inches(.7);sec.left_margin=sec.right_margin=Inches(.8)
sec.page_width=Inches(8.5);sec.page_height=Inches(11)
for name in ['Normal','Title','Subtitle','Heading 1','Heading 2']:
 s=d.styles[name];s.font.name='Arial';s.font.color.rgb=RGBColor(0,0,0)
d.styles['Normal'].font.size=Pt(11)
d.styles['Normal'].paragraph_format.line_spacing=1.12
d.styles['Normal'].paragraph_format.space_after=Pt(9)
d.styles['Title'].font.size=Pt(29);d.styles['Heading 1'].font.size=Pt(20);d.styles['Heading 2'].font.size=Pt(13)

def p(s):d.add_paragraph(s)
def h(s):d.add_heading(s,2)
def page(s):
 q=d.add_heading(s,1);q.paragraph_format.page_break_before=True

def table(head,rows,widths):
 t=d.add_table(rows=1,cols=len(head));t.autofit=False
 for i,w in enumerate(widths):t.columns[i].width=Inches(w)
 for i,v in enumerate(head):t.rows[0].cells[i].text=v
 for row in rows:
  for i,v in enumerate(row):t.add_row() if False else None
  cells=t.add_row().cells
  for i,v in enumerate(row):cells[i].text=str(v)
 for ri,row in enumerate(t.rows):
  for ci,c in enumerate(row.cells):
   c.width=Inches(widths[ci]);pr=c._tc.get_or_add_tcPr()
   shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'E6EAF0' if ri==0 else 'FFFFFF');pr.append(shade)
   mar=OxmlElement('w:tcMar')
   for side in ['top','left','bottom','right']:
    el=OxmlElement('w:'+side);el.set(qn('w:w'),'100');el.set(qn('w:type'),'dxa');mar.append(el)
   pr.append(mar);borders=OxmlElement('w:tcBorders')
   for side in ['top','left','bottom','right']:
    el=OxmlElement('w:'+side);el.set(qn('w:val'),'single');el.set(qn('w:sz'),'4');el.set(qn('w:color'),'D9D9D9');borders.append(el)
   pr.append(borders)
   for q in c.paragraphs:
    q.paragraph_format.space_after=Pt(2);q.paragraph_format.line_spacing=1.05
    for run in q.runs:run.font.size=Pt(10);run.bold=ri==0
  trpr=row._tr.get_or_add_trPr();trpr.append(OxmlElement('w:cantSplit'))
 t.rows[0]._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
 d.add_paragraph().paragraph_format.space_after=Pt(1)

d.add_paragraph('FitLore Rescue',style='Title')
d.add_paragraph('Week 3 project report',style='Subtitle')
p('FitLore Rescue helps a stylist recover a fashion shoot when its hero jacket becomes unavailable. It investigates affected looks, checks replacement garments against the brief, and waits for human approval before updating the local production plan.')
p('FitLore combines editable shoot briefs, CSV wardrobe import, model-selected tools, durable approval and transaction-safe updates. Ten fictional live evaluation cases passed their defined acceptance criteria. These bounded tests are evidence of behavior, not a general reliability guarantee.')
h('The problem and the user')
p('A stylist must connect a garment change to every affected look, check the brief and timing, compare options, and obtain approval. FitLore keeps that investigation and its evidence in one workspace. The demo uses a fictional campaign called The Monday Edit.')
h('The demonstration')
table(['Before','After approval'],[['Hero navy blazer G01 is unavailable','Studio navy blazer G02 replaces G01'],['Two looks are blocked','Both looks reference the approved replacement'],['Replacement ceiling is $60','Recorded replacement cost is $45'],['Stylist and photographer reviews are open','Both reviews remain open']], [3.4,3.4])
h('What changed from Week 2')
p('Week 2 established FitLore’s styling and production-planning concept. This focused companion build reuses its visual identity and licensed category photography. The new work is a model-selected tool loop, persistent approval, failure handling, and an atomic plan update. It does not migrate the previous database.')
h('Success criterion')
p('Target: at least 8 of 10 varied cases reach the correct completion, rejection or handoff within 180 seconds of system processing, with zero writes before approval. Manual coordination is estimated at 10–15 minutes per incident; that baseline is an assumption, not a measured saving.')

page('Architecture and control')
d.add_picture(str(out/'architecture.png'),width=Inches(6.8))
p('The model selects one allowlisted tool at each step. Tool results return to the model. Python enforces the hard constraints, and LangGraph saves state between nodes. An approval interrupt persists until the user approves or rejects the proposal.')
table(['Component','Configuration or role'],[['Model','Qwen/Qwen3-30B-A3B-Instruct-2507 through Nebius Token Factory'],['Orchestration','Python LangGraph 1.2.17; schema-constrained action selection'],['Persistence','SQLite workspace and LangGraph SQLite checkpointer'],['Interface','FastAPI with local HTML, CSS and JavaScript'],['Retrieval','Structured local records; no vector index or embeddings in this workflow'],['Request limits','80 model attempts authorized; 10 steps per run; at least six reserved for recording']], [1.5,5.3])
h('Tools and the write boundary')
p('read_shoot, inspect_impact and search_wardrobe read the evidence. check_replacement validates category, availability, color, recorded size, sleeve coverage, timing and cost. propose_replacement prepares an approval request. handoff stops with an explanation.')
p('The model cannot write the plan. A reviewer can approve, reject or choose another validated candidate. The transaction rechecks the saved shoot revision and candidate constraints, then updates the saved shoot and run snapshot together. A unique run ID prevents duplicate writes.')
h('Failure handling and memory')
p('The inventory demonstration permits one retry and hands off after two failures. Model service errors and a ten-step limit also stop safely. Run observations, approval state, and event history survive reopening. This is durable workflow memory, not learned user preferences.')

page('Evidence and limitations')
h('Data used')
table(['Data','Origin and scope'],[['Shoot brief','Fictional local brief with a $60 replacement ceiling and 10:00 call time'],['Wardrobe','Eight fictional garment records, including five jackets and three supporting items'],['Production','Two looks that share the jacket at separate slots, plus two review tasks'],['Photography','Three existing FitLore category photos; Pexels credits are included in the app'],['Evaluation','25 deterministic tests, two exploratory live runs and ten structured live evaluation cases']], [1.5,5.3])
h('Observed live results')
table(['Scenario','Observed outcome','Requests'],[['Inventory fails once','Recovered; human approval updated both looks','7'],['No suitable replacement','Rejected unsuitable candidates; handed off without a write','7']], [1.8,4.2,.8])
p('The table shows the two original exploratory runs. The subsequent ten-case evaluation passed standard recovery, retry, permanent outage, no match, rejection, a white-shirt brief, insufficient budget, injected instructions, stale approval and size mismatch. System times were under 7 seconds; simulated reviewer time is excluded. Full timings, actions and outcomes are in live-evaluation.json.')
h('Automated verification')
p('25 automated tests passed, covering the original approval, persistence and failure controls plus saved-shoot updates, concurrent edits, human alternatives, custom categories, CSV validation and the expanded request cap. These deterministic tests are separate from the live model evaluation.')
h('Practical limits')
p('This single-user localhost prototype accepts editable briefs, CSV wardrobe records and affected looks. Saved shoots persist across investigations; demo scenarios use independent copies. Evaluation data is fictional. It cannot verify live stock or physical fit, reserve garments, send messages or spend money. Remote deployment and authentication remain outside scope.')

page('Prompts iterations and learnings')
h('How AI coding tools were used')
p('Codex inspected Week 2, translated the handout into a focused workflow, built the interface and backend, and tested the browser flow. The user first authorized 20 Nebius requests, then extended the total to 80 for fictional evaluation data.')
h('Build instructions and runtime prompt')
p('User prompts included “lets build on fitlore” and “fix all partial, missing, mostly meets, meets all of those as exceeded”. These drove a focused rescue workflow, then editable shoots, validated alternatives and a measured evaluation. Runtime task: “Rescue tomorrow’s shoot within the brief and budget.”')
p('The runtime system prompt requires one JSON tool decision, treats source text as untrusted data, lists the allowed tools, requires evidence and a successful candidate check before proposing, limits inventory retries, and requires handoff when no garment qualifies. The complete prompt is versioned in app/agent.py.')
h('Iterations completed')
table(['Iteration','Change and reason'],[['Focused scope','Built a companion rescue workflow instead of expanding all Week 2 features'],['Control layer','Added required-evidence checks, candidate validation, a saved approval interrupt, and an idempotent transaction'],['Verification','Added 25 tests and ten structured live cases, including changed briefs and injected instructions'],['Browser refinement','Added reusable shoot editor, CSV import and validated alternatives; verified browser save and approval']], [1.5,5.3])
h('What the work showed')
p('Structured model output constrains the action format, but it does not make the decision correct. The no-match run demonstrated why the application must validate availability and timing before offering a write. Durable approval state also makes the workflow easier to demonstrate and resume.')
p('The expanded evaluation and editable shoots are implemented. Next work is an authenticated inventory integration and independent stylist testing. Local records remain until the operator removes the runtime database; no automatic expiry or learned preferences are implemented.')
h('Technical references')
p('LangGraph interrupts: https://docs.langchain.com/oss/python/langgraph/interrupts\nLangGraph persistence: https://docs.langchain.com/oss/python/langgraph/persistence\nPhoto source links: web/images/credits.json\nLive evidence: output/submission/live-evidence.json and live-evaluation.json')
d.save(out/'FitLore Rescue Project Report.docx')
print(out/'FitLore Rescue Project Report.docx')
